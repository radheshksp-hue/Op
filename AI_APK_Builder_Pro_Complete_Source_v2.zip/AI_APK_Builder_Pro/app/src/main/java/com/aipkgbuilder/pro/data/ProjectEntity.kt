package com.aipkgbuilder.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val originalArchiveName: String,
    val originalZipPath: String,
    val workspacePath: String,
    val projectRootPath: String,
    val createdAt: Long,
    val lastBuildAt: Long? = null,
    val currentStatus: String = "ANALYZED",
    val lastJobId: String? = null,
    val releaseTag: String? = null,
    val releaseId: Long? = null,
    val workflowRunId: Long? = null,
    val repairAttempts: Int = 0,
    val apkPath: String? = null,
    val apkSha256: String? = null,
    val diagnosticsPath: String? = null,
    val lastMessage: String? = null
)
