package com.aipkgbuilder.pro.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ProjectEntity::class, BuildAttemptEntity::class], version = 1, exportSchema = true)
abstract class BuilderDatabase : RoomDatabase() {
    abstract fun builderDao(): BuilderDao

    companion object {
        @Volatile private var instance: BuilderDatabase? = null
        fun get(context: Context): BuilderDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                BuilderDatabase::class.java,
                "apk_builder.db"
            ).build().also { instance = it }
        }
    }
}
