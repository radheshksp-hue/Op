package com.aipkgbuilder.pro.zip

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.os.StatFs
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipFile
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max

class ZipSafetyException(message: String) : Exception(message)

 data class SelectedArchive(val file: File, val displayName: String, val sizeBytes: Long)
 data class ProjectModule(val name: String, val relativePath: String, val applicationModule: Boolean)
 data class ProjectSummary(
    val projectRoot: File,
    val detectedName: String,
    val modules: List<ProjectModule>,
    val applicationId: String?,
    val minSdk: String?,
    val targetSdk: String?,
    val compileSdk: String?,
    val kotlinVersion: String?,
    val agpVersion: String?,
    val gradleVersion: String?,
    val javaCompatibility: String?,
    val hasWrapper: Boolean,
    val hasManifest: Boolean,
    val sourceFileCount: Int,
    val totalFileCount: Int,
    val readiness: String,
    val warnings: List<String>
) {
    fun displayText(): String = buildString {
        appendLine("Project: $detectedName")
        appendLine("Root: ${projectRoot.absolutePath}")
        appendLine("Modules: ${modules.joinToString { it.name + if (it.applicationModule) " (app)" else "" }.ifBlank { "Not detected" }}")
        appendLine("Application ID: ${applicationId ?: "Not detected"}")
        appendLine("SDK: min ${minSdk ?: "?"} · target ${targetSdk ?: "?"} · compile ${compileSdk ?: "?"}")
        appendLine("Kotlin: ${kotlinVersion ?: "Not detected"} · AGP: ${agpVersion ?: "Not detected"} · Gradle: ${gradleVersion ?: "Not detected"}")
        appendLine("Java compatibility: ${javaCompatibility ?: "Not detected"}")
        appendLine("Gradle Wrapper: ${if (hasWrapper) "Present" else "Missing"} · Manifest: ${if (hasManifest) "Present" else "Missing"}")
        appendLine("Files: $totalFileCount total, $sourceFileCount source/resource files")
        appendLine("Readiness: $readiness")
        warnings.forEach { appendLine("• $it") }
    }
}

data class PackagingReport(val sourceZip: File, val includedFiles: Int, val excludedPaths: List<String>, val sha256: String)

class ProjectProcessor(private val context: Context) {
    companion object {
        const val MAX_ARCHIVE_BYTES = 100L * 1024L * 1024L
        const val MAX_EXTRACTED_BYTES = 1024L * 1024L * 1024L
        const val MAX_ENTRIES = 50_000
        const val MAX_ENTRY_BYTES = 250L * 1024L * 1024L
        const val MAX_NESTING = 64
        private const val MIN_FREE_SPACE = 64L * 1024L * 1024L
    }

    fun archiveDisplayName(resolver: ContentResolver, uri: Uri): String {
        var candidate: String? = null
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) candidate = cursor.getString(0)
        }
        return candidate?.takeIf { it.isNotBlank() }?.let { File(it).name }
            ?: "project-${UUID.randomUUID().toString().take(8)}.zip"
    }

    fun copySelectedArchive(uri: Uri, destinationDir: File, onProgress: (Long, Long?) -> Unit = { _, _ -> }): SelectedArchive {
        val name = archiveDisplayName(context.contentResolver, uri)
        if (!name.lowercase(Locale.US).endsWith(".zip")) throw ZipSafetyException("Please select a .zip Android Studio project archive.")
        var reportedSize: Long? = null
        context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst() && !cursor.isNull(0)) reportedSize = cursor.getLong(0).takeIf { it >= 0L }
        }
        if (reportedSize != null && reportedSize!! > MAX_ARCHIVE_BYTES) {
            throw ZipSafetyException("ZIP is ${(reportedSize!! / 1024 / 1024)} MB. Current limit is 100 MB; increase the app limit or select a smaller archive.")
        }
        destinationDir.mkdirs()
        val destination = File(destinationDir, "original-${UUID.randomUUID()}.zip")
        var copied = 0L
        try {
            val input = context.contentResolver.openInputStream(uri) ?: throw ZipSafetyException("Android could not open this document provider's file.")
            input.use { source ->
                BufferedInputStream(source).use { buffered ->
                    FileOutputStream(destination).use { output ->
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        while (true) {
                            val count = buffered.read(buffer)
                            if (count < 0) break
                            copied += count
                            if (copied > MAX_ARCHIVE_BYTES) throw ZipSafetyException("The actual file is larger than the 100 MB ZIP limit.")
                            output.write(buffer, 0, count)
                            onProgress(copied, reportedSize)
                        }
                        output.fd.sync()
                    }
                }
            }
            if (reportedSize != null && copied != reportedSize) {
                throw ZipSafetyException("Copied size did not match the file provider's reported size. Please select the ZIP again.")
            }
            if (copied < 22L) throw ZipSafetyException("The selected file is too small to be a valid ZIP archive.")
            return SelectedArchive(destination, name, copied)
        } catch (error: Exception) {
            destination.delete()
            if (error is ZipSafetyException) throw error
            throw ZipSafetyException("Could not copy the selected ZIP: ${error.message ?: error.javaClass.simpleName}")
        }
    }

    fun extractAndAnalyze(zipFile: File, projectWorkspace: File): ProjectSummary {
        if (!zipFile.isFile || zipFile.length() < 22L) throw ZipSafetyException("ZIP file is missing or empty.")
        if (zipFile.length() > MAX_ARCHIVE_BYTES) throw ZipSafetyException("ZIP exceeds the 100 MB limit.")
        val stat = StatFs(context.filesDir.absolutePath)
        if (stat.availableBytes < MIN_FREE_SPACE) throw ZipSafetyException("Not enough free device storage to safely extract a project.")
        if (projectWorkspace.exists()) projectWorkspace.deleteRecursively()
        if (!projectWorkspace.mkdirs()) throw ZipSafetyException("Could not create a private extraction workspace.")
        val seenFiles = HashSet<String>()
        var entryCount = 0
        var declaredTotal = 0L
        var actualExpandedBytes = 0L
        val allowedExpandedBytes = minOf(MAX_EXTRACTED_BYTES, max(256L * 1024L * 1024L, zipFile.length() * 250L))
        try {
            ZipFile.builder().setFile(zipFile).get().use { archive ->
                val entries = archive.entries
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    entryCount++
                    if (entryCount > MAX_ENTRIES) throw ZipSafetyException("Archive contains more than $MAX_ENTRIES entries.")
                    val normalizedName = validateEntryName(entry)
                    if (entry.isUnixSymlink) throw ZipSafetyException("Symbolic links are not accepted in uploaded ZIPs: $normalizedName")
                    val output = File(projectWorkspace, normalizedName).canonicalFile
                    val root = projectWorkspace.canonicalFile
                    if (output != root && !output.path.startsWith(root.path + File.separator)) {
                        throw ZipSafetyException("Archive entry escapes the extraction workspace: $normalizedName")
                    }
                    if (entry.isDirectory) {
                        output.mkdirs()
                        continue
                    }
                    val canonicalKey = output.path.lowercase(Locale.US)
                    if (!seenFiles.add(canonicalKey)) throw ZipSafetyException("Duplicate archive file path: $normalizedName")
                    val entrySize = entry.size
                    if (entrySize > MAX_ENTRY_BYTES) throw ZipSafetyException("Archive entry is larger than 250 MB: $normalizedName")
                    if (entrySize > 0) {
                        declaredTotal += entrySize
                        if (declaredTotal > allowedExpandedBytes || declaredTotal > MAX_EXTRACTED_BYTES) {
                            throw ZipSafetyException("ZIP expands beyond the configured safety limit. This may be a decompression bomb.")
                        }
                    }
                    if (normalizedName.split('/').size > MAX_NESTING) throw ZipSafetyException("Archive path is nested too deeply: $normalizedName")
                    output.parentFile?.mkdirs()
                    if (output.exists()) throw ZipSafetyException("Archive would overwrite an existing extracted path: $normalizedName")
                    var entryWritten = 0L
                    archive.getInputStream(entry).use { input ->
                        BufferedInputStream(input).use { source ->
                            BufferedOutputStream(FileOutputStream(output, false)).use { dest ->
                                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                                while (true) {
                                    val read = source.read(buffer)
                                    if (read < 0) break
                                    entryWritten += read
                                    actualExpandedBytes += read
                                    if (entryWritten > MAX_ENTRY_BYTES) throw ZipSafetyException("Expanded archive entry exceeds 250 MB: $normalizedName")
                                    if (actualExpandedBytes > allowedExpandedBytes || actualExpandedBytes > MAX_EXTRACTED_BYTES) {
                                        throw ZipSafetyException("ZIP expanded size exceeded its safety limit while extracting.")
                                    }
                                    dest.write(buffer, 0, read)
                                }
                            }
                        }
                    }
                    if (entrySize >= 0 && entryWritten != entrySize) throw ZipSafetyException("ZIP entry size does not match its directory metadata: $normalizedName")
                }
            }
        } catch (error: ZipSafetyException) {
            projectWorkspace.deleteRecursively()
            throw error
        } catch (error: Exception) {
            projectWorkspace.deleteRecursively()
            throw ZipSafetyException("ZIP is corrupt or cannot be read: ${error.message ?: error.javaClass.simpleName}")
        }
        val projectRoot = detectProjectRoot(projectWorkspace)
            ?: run { projectWorkspace.deleteRecursively(); throw ZipSafetyException("No convincing Android Gradle project root was found. Expected settings.gradle(.kts), Android build files, a manifest, or a Gradle Wrapper.") }
        return analyzeProject(projectRoot)
    }

    private fun validateEntryName(entry: ZipArchiveEntry): String {
        val raw = entry.name.replace('\\', '/')
        if (raw.isBlank() || raw.startsWith('/') || Regex("^[A-Za-z]:").containsMatchIn(raw)) {
            throw ZipSafetyException("Absolute or empty archive path rejected.")
        }
        val parts = raw.split('/')
        if (parts.any { it == ".." || it == "." || it.isEmpty() && it != parts.lastOrNull() }) {
            throw ZipSafetyException("Unsafe path traversal or ambiguous path rejected: $raw")
        }
        if (parts.any { it.contains('\u0000') }) throw ZipSafetyException("Null character in archive path rejected.")
        return parts.filter { it.isNotEmpty() }.joinToString("/")
    }

    fun detectProjectRoot(workspace: File): File? = AndroidProjectRootDetector.detect(workspace)

    fun analyzeExistingProjectRoot(root: File): ProjectSummary = analyzeProject(root.canonicalFile)

    private fun analyzeProject(root: File): ProjectSummary {
        val files = root.walkTopDown().maxDepth(40).filter { it.isFile && !it.path.contains("${File.separator}build${File.separator}") && !it.path.contains("${File.separator}.gradle${File.separator}") }.toList()
        val gradleFiles = files.filter { it.name in setOf("build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "gradle.properties", "libs.versions.toml") }
        val gradleText = gradleFiles.joinToString("\n") { it.readTextBounded() }
        val settingsFile = files.firstOrNull { it.name == "settings.gradle.kts" } ?: files.firstOrNull { it.name == "settings.gradle" }
        val settingsText = settingsFile?.readTextBounded().orEmpty()
        val moduleNames = Regex("include\\s*\\(?([^\\n)]+)\\)?").findAll(settingsText).flatMap { match ->
            Regex("[\"'](:[A-Za-z0-9_:-]+)[\"']").findAll(match.groupValues[1]).map { it.groupValues[1].removePrefix(":").replace(':', '/') }
        }.toSet()
        val modules = mutableListOf<ProjectModule>()
        val moduleDirs = (moduleNames + setOf(":app".removePrefix(":"))).map { it.replace('/', File.separatorChar) }.distinct().map { File(root, it) }
        moduleDirs.filter { it.exists() }.forEach { dir ->
            val build = sequenceOf(File(dir, "build.gradle.kts"), File(dir, "build.gradle")).firstOrNull { it.isFile }
            val text = build?.readTextBounded().orEmpty()
            val app = text.contains("com.android.application")
            if (build != null || File(dir, "src/main/AndroidManifest.xml").exists()) {
                modules += ProjectModule(dir.name, root.toPath().relativize(dir.toPath()).toString().ifBlank { "." }, app)
            }
        }
        // Also discover modules when settings syntax is unusual or includes are generated.
        if (modules.isEmpty()) {
            files.filter { it.name in setOf("build.gradle", "build.gradle.kts") }.forEach { build ->
                val text = build.readTextBounded()
                if (text.contains("com.android.application") || text.contains("com.android.library")) {
                    val app = text.contains("com.android.application")
                    modules += ProjectModule(build.parentFile.name, root.toPath().relativize(build.parentFile.toPath()).toString().ifBlank { "." }, app)
                }
            }
        }
        val manifest = files.firstOrNull { it.name == "AndroidManifest.xml" }
        val manifestText = manifest?.readTextBounded().orEmpty()
        val appId = Regex("applicationId\\s*(?:=\\s*)?[\"']([^\"']+)[\"']").find(gradleText)?.groupValues?.get(1)
            ?: Regex("package\\s*=\\s*[\"']([^\"']+)[\"']").find(manifestText)?.groupValues?.get(1)
        val minSdk = Regex("minSdk(?:Version)?\\s*(?:=\\s*)?(?:[\"']([^\"']+)[\"']|(\\d+))").find(gradleText)?.let { it.groupValues[1].ifBlank { it.groupValues[2] } }
        val targetSdk = Regex("targetSdk(?:Version)?\\s*(?:=\\s*)?(?:[\"']([^\"']+)[\"']|(\\d+))").find(gradleText)?.let { it.groupValues[1].ifBlank { it.groupValues[2] } }
        val compileSdk = Regex("compileSdk(?:Version)?\\s*(?:=\\s*)?(?:[\"']([^\"']+)[\"']|(\\d+))").find(gradleText)?.let { it.groupValues[1].ifBlank { it.groupValues[2] } }
        val kotlinVersion = Regex("(?:org\\.jetbrains\\.kotlin\\.android|kotlin\\(\\\"android\\\"\\)|kotlin-gradle-plugin)[^\\n]{0,100}version\\s*[\"']([^\"']+)").find(gradleText)?.groupValues?.get(1)
            ?: Regex("kotlin\\s*=\\s*[\"']([^\"']+)[\"']").find(gradleText)?.groupValues?.get(1)
        val agpVersion = Regex("com\\.android\\.(?:application|library)[^\\n]{0,100}version\\s*[\"']([^\"']+)").find(gradleText)?.groupValues?.get(1)
            ?: Regex("com\\.android\\.tools\\.build:gradle:([^'\"\\s]+)").find(gradleText)?.groupValues?.get(1)
        val wrapperFile = File(root, "gradle/wrapper/gradle-wrapper.properties")
        val gradleVersion = wrapperFile.takeIf { it.isFile }?.readTextBounded()?.let { Regex("gradle-([0-9][^-/]+)-(?:bin|all)\\.zip").find(it)?.groupValues?.get(1) }
        val javaCompatibility = Regex("(?:JavaVersion\\.VERSION_([0-9_]+)|jvmTarget\\s*(?:=\\s*)?[\"']([^\"']+)|VERSION_([0-9_]+))").find(gradleText)?.let { it.groupValues.drop(1).firstOrNull { s -> s.isNotBlank() } }
        val hasWrapper = File(root, "gradlew").isFile && File(root, "gradlew.bat").isFile && wrapperFile.isFile && File(root, "gradle/wrapper/gradle-wrapper.jar").isFile
        val hasManifest = manifest != null
        val sourceCount = files.count { it.extension.lowercase(Locale.US) in setOf("kt", "java", "xml", "aidl", "rs", "properties", "gradle", "kts") }
        val warnings = mutableListOf<String>()
        if (!hasWrapper) warnings += "Gradle Wrapper files are missing. Add the real gradlew script, wrapper JAR, and wrapper properties before building."
        if (!hasManifest) warnings += "No AndroidManifest.xml was found below the detected root. Verify this is an Android Gradle project."
        if (modules.none { it.applicationModule }) warnings += "No Android application module was confidently detected. The workflow may need an explicit APK_BUILD_TASK repository variable."
        if (settingsFile == null) warnings += "No settings.gradle(.kts) was found at the root; module discovery may be incomplete."
        if (File(root, "local.properties").isFile) warnings += "local.properties was found. Its local SDK path will be excluded from the upload package."
        if (files.any { it.name.endsWith(".jks", true) || it.name.endsWith(".keystore", true) }) warnings += "Signing material was found. It will be excluded from the source upload package."
        val readiness = when {
            !hasManifest || modules.isEmpty() -> "Unsupported or invalid structure"
            !hasWrapper || modules.none { it.applicationModule } -> "Ready with warnings"
            else -> "Ready to attempt build"
        }
        return ProjectSummary(
            projectRoot = root,
            detectedName = root.name.ifBlank { "Android Project" },
            modules = modules.distinctBy { it.relativePath },
            applicationId = appId,
            minSdk = minSdk,
            targetSdk = targetSdk,
            compileSdk = compileSdk,
            kotlinVersion = kotlinVersion,
            agpVersion = agpVersion,
            gradleVersion = gradleVersion,
            javaCompatibility = javaCompatibility,
            hasWrapper = hasWrapper,
            hasManifest = hasManifest,
            sourceFileCount = sourceCount,
            totalFileCount = files.size,
            readiness = readiness,
            warnings = warnings
        )
    }

    fun createCleanSourceZip(projectRoot: File, zipFile: File): PackagingReport {
        val root = projectRoot.canonicalFile
        if (!root.isDirectory) throw ZipSafetyException("Project root is no longer available.")
        zipFile.parentFile?.mkdirs()
        if (zipFile.exists()) zipFile.delete()
        val excluded = mutableListOf<String>()
        var included = 0
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zipOut ->
                root.walkTopDown().forEach { file ->
                    if (file.isDirectory) {
                        if (file != root && shouldSkipDirectory(file, root)) {
                            excluded += relative(root, file) + "/"
                            file.walkTopDown().filter { it.isFile }.forEach { child -> if (child != file) excluded += relative(root, child) }
                        }
                        return@forEach
                    }
                    val relativePath = relative(root, file)
                    if (shouldExcludeFile(file, relativePath)) {
                        excluded += relativePath
                        return@forEach
                    }
                    val entry = ZipEntry(relativePath.replace(File.separatorChar, '/')).apply { time = 0L }
                    zipOut.putNextEntry(entry)
                    file.inputStream().buffered().use { it.copyTo(zipOut) }
                    zipOut.closeEntry()
                    included++
                }
            }
        } catch (error: Exception) {
            zipFile.delete()
            throw ZipSafetyException("Could not package source project: ${error.message ?: error.javaClass.simpleName}")
        }
        if (included == 0) {
            zipFile.delete()
            throw ZipSafetyException("No source files remained after excluding generated output and detected secrets.")
        }
        return PackagingReport(zipFile, included, excluded.distinct().sorted(), sha256(zipFile))
    }

    private fun shouldSkipDirectory(file: File, root: File): Boolean =
        ProjectFilePolicy.shouldSkipDirectory(relative(root, file))

    private fun shouldExcludeFile(file: File, relativePath: String): Boolean =
        ProjectFilePolicy.shouldExcludeFile(file, relativePath)

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val size = input.read(buffer)
                if (size < 0) break
                digest.update(buffer, 0, size)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun relative(root: File, file: File): String = root.toPath().relativize(file.toPath()).toString()
    private fun File.readTextBounded(maxBytes: Long = 1024L * 1024L): String = if (isFile && length() <= maxBytes) runCatching { readText(Charsets.UTF_8) }.getOrDefault("") else ""
    private fun File.depthFrom(root: File): Int = runCatching { root.toPath().relativize(toPath()).nameCount }.getOrDefault(Int.MAX_VALUE)
}
