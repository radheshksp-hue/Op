package com.aipkgbuilder.pro.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppDark = darkColorScheme(
    primary = Color(0xFFB8B8FF),
    onPrimary = Color(0xFF191943),
    secondary = Color(0xFF80D8C8),
    background = Color(0xFF101119),
    surface = Color(0xFF191B25),
    surfaceVariant = Color(0xFF292B39),
    error = Color(0xFFFFB4AB)
)
private val AppLight = lightColorScheme(
    primary = Color(0xFF4548C8),
    onPrimary = Color.White,
    secondary = Color(0xFF14695D),
    background = Color(0xFFF7F7FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFE8E8F2),
    error = Color(0xFFB3261E)
)

@Composable
fun BuilderTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) AppDark else AppLight, content = content)
}
