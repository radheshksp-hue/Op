package com.aipkgbuilder.pro

import android.app.Application
import androidx.work.Configuration

class BuilderApplication : Application(), Configuration.Provider {
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().setMinimumLoggingLevel(android.util.Log.INFO).build()
}
