@echo off
rem Temporary distribution bootstrap; not the official Gradle Wrapper.
rem On a connected machine run: gradlew.bat wrapper --gradle-version 8.13 --distribution-type bin
setlocal
set VERSION=8.13
set DIST=gradle-%VERSION%-bin.zip
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set BASE=%GRADLE_USER_HOME%\ai-apk-builder-bootstrap
set INSTALL=%BASE%\gradle-%VERSION%
if exist "%INSTALL%\bin\gradle.bat" goto RUN_GRADLE
if not exist "%BASE%" mkdir "%BASE%"
set ARCHIVE=%BASE%\%DIST%
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $u='https://services.gradle.org/distributions/%DIST%'; Invoke-WebRequest -UseBasicParsing $u -OutFile '%ARCHIVE%'; Invoke-WebRequest -UseBasicParsing ($u+'.sha256') -OutFile '%ARCHIVE%.sha256'; $expected=(Get-Content '%ARCHIVE%.sha256' -Raw).Trim().Split(' ')[0]; $actual=(Get-FileHash '%ARCHIVE' -Algorithm SHA256).Hash.ToLowerInvariant(); if ($actual -ne $expected.ToLowerInvariant()) { Remove-Item '%ARCHIVE' -Force; throw 'Gradle distribution SHA-256 check failed.' }; Expand-Archive -Path '%ARCHIVE%' -DestinationPath '%BASE%' -Force"
if errorlevel 1 exit /b %errorlevel%
:RUN_GRADLE
call "%INSTALL%\bin\gradle.bat" %*
exit /b %errorlevel%
